const setToken = token => {
  sessionStorage.setItem('token', token)
}
const getToken = () => {
  return sessionStorage.getItem('token')
}
const setRouters = routers => {
  sessionStorage.setItem('routers', routers)
}
const getRouters = () => {
  return sessionStorage.getItem('routers')
}
const setRole = role => {
  sessionStorage.setItem('role', role)
}
const removeItem = item => {
  sessionStorage.removeItem(item)
}
const getRole = () => {
  sessionStorage.getItem('role')
}
const setUserName = (userName) => {
  sessionStorage.setItem('userName', userName)
}
const getUserName = () => {
  return sessionStorage.getItem('userName')
}

const setAvatar = (avatar) => {
  sessionStorage.setItem('avatar', avatar)
}
const getAvatar = () => {
  return sessionStorage.getItem('avatar')
}

const session = {
  setToken,
  getToken,
  setRouters,
  getRouters,
  setRole,
  getRole,
  setUserName,
  getUserName,
  setAvatar,
  getAvatar,
  removeItem
}

export default session
