import request from '@/utils/request'

const login = (params) => {
  return request({
    url: '/login',
    method: 'post',
    data: params
  })
}

const authorize = () => {
  return request({
    url: '/authorize',
    method: 'get'
  })
}

const auth = {
  login,
  authorize
}
export default auth
