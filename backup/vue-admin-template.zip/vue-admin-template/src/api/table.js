import { tableItems } from './data/data'
export function getList(params) {
  return new Promise((resolve, rejects) => {
    resolve(tableItems)
  })
}
