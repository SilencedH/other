import session from '@/utils/sessionUtils'
import { authorized } from '@/api/data/data'
const user = {
  state: {
    token: session.getToken(),
    name: '',
    avatar: '',
    role: ''
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLE: (state, role) => {
      state.role = role
    }
  },

  actions: {
    // 登录
    Login({ commit }, userInfo) {
      return new Promise((resolve, reject) => {
        session.setToken('1234567890')
        resolve()
      })
    },

    // 获取用户信息
    GetInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        session.setRole(authorized.role)
        session.setUserName(authorized.userName)
        session.setAvatar('/src/assets/avatar.gif')
        resolve()
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        session.removeItem('token')
        resolve()
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        session.removeItem('token')
        resolve()
      })
    }
  }
}

export default user
