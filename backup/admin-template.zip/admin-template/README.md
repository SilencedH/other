# admin-template

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

``` bash
# 按装element-ui
npm i element-ui -S

# 按装 axios
npm install axios

# 安装 vuex
npm install vuex --save

#安装 sass-loader
npm install sass-loader

# 安装 node-sass
npm install node-sass

```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
