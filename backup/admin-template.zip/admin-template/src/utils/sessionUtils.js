const setSideBarStatus = status => sessionStorage.setItem('sideBarStatus', status)
const getSideBarStatus = () => { return sessionStorage.getItem('sideBarStatus') }
const setLanguage = (language) => sessionStorage.setItem('language', language)
const getLanguage = () => { return sessionStorage.getItem('language') }
const setSize = (size) => sessionStorage.setItem('size', size)
const getSize = () => { return sessionStorage.getItem('size') }
export {
  setSideBarStatus,
  getSideBarStatus,
  setLanguage,
  getLanguage,
  setSize,
  getSize
}
