const user = {
  state: {

  },
  mutations: {

  },
  actions: {
    // 登录
    Login({commit}, loginForm) {
      return new Promise((resolve, reject) => {
        resolve('12345678')
      })
    },
    authorize({commit}, token) {
      return new Promise((resolve, reject) => {
        let authorize = {

        }
        resolve(authorize)
      })
    }
  }
}

export default user
